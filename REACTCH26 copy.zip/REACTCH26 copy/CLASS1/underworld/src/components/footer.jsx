import './footer.css'

const Footer = () => {
    return (<div className='footer'>
                <h4>underworld&copy;  </h4>
                <h4>Developer: Santiago Quijano</h4>
            </div>);
};

export default Footer;