import './navBar.css'

const NavBar = () => {
    return (<div className='navBar'>
                <h2>This will be the NavBar!</h2>
            </div>);
};

export default NavBar;

